# -*- coding: utf-8 -*-





class 实盘价格子图:
	'''

	'''

	def __init__(self, parent, 绘图数据):
		'''

		'''
		pass







