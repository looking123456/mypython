# -*- coding: utf-8 -*-





class 实盘手数子图:
	'''

	'''

	def __init__(self, parent, 绘图数据, 价格子图):
		'''

		'''
		pass






